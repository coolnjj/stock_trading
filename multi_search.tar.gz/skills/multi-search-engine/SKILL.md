---
name: multi-search-engine
description: "Integration of 17 search engines for web crawling without API keys. Default source: Baidu (百度). Supports domestic and international search engines including Baidu, Bing, Google, DuckDuckGo, WolframAlpha etc."
metadata:
---

# Multi Search Engine
Integration of 17 search engines for web crawling without API keys.

**默认搜索源：百度（https://www.baidu.com）**

> ⚠️ 注意：在中国大陆环境下，优先使用百度搜索。国际搜索引擎（DuckDuckGo、Google等）需要代理才能访问。

## ⚠️ WSL 使用注意

`web_search` 工具在 WSL 环境下默认走 DuckDuckGo，无法访问。
**请直接使用 `web_fetch` + 百度URL 进行搜索**，示例见下方 Quick Examples。

## Search Engines

### Domestic (8)
- Baidu: https://www.baidu.com/s?wd={keyword}
- Bing CN: https://cn.bing.com/search?q={keyword}&ensearch=0
- Bing INT: https://cn.bing.com/search?q={keyword}&ensearch=1
- 360: https://www.so.com/s?q={keyword}
- Sogou: https://sogou.com/web?query={keyword}
- WeChat: https://wx.sogou.com/weixin?type=2&query={keyword}
- Toutiao: https://so.toutiao.com/search?keyword={keyword}
- Jisilu: https://www.jisilu.cn/explore/?keyword={keyword}

### International (9)
- Google: https://www.google.com/search?q={keyword}
- Google HK: https://www.google.com.hk/search?q={keyword}
- DuckDuckGo: https://duckduckgo.com/html/?q={keyword}
- Yahoo: https://search.yahoo.com/search?p={keyword}
- Startpage: https://www.startpage.com/sp/search?query={keyword}
- Brave: https://search.brave.com/search?q={keyword}
- Ecosia: https://www.ecosia.org/search?q={keyword}
- Qwant: https://www.qwant.com/?q={keyword}
- WolframAlpha: https://www.wolframalpha.com/input?i={keyword}

## Quick Examples
// Basic search (百度)
web_fetch({"url": "https://www.baidu.com/s?wd=python教程"})

// Basic search (Bing CN)
web_fetch({"url": "https://cn.bing.com/search?q=python教程"})

// Site-specific (百度)
web_fetch({"url": "https://www.baidu.com/s?wd=site:github.com+react"})

// File type (百度)
web_fetch({"url": "https://www.baidu.com/s?wd=机器学习+filetype:pdf"})

// Time filter (百度 - past week)
web_fetch({"url": "https://www.baidu.com/s?wd=AI新闻&tn=news&tbs=qdr:w"})

// Sogou (搜狗微信搜索)
web_fetch({"url": "https://sogou.com/web?query=关键词"})

// Knowledge calculation
web_fetch({"url": "https://www.wolframalpha.com/input?i=100+USD+to+CNY"})

## Advanced Operators
OperatorExampleDescription
site:site:github.com python站内搜索
filetype:filetype:pdf 报告搜索特定文件类型
"""机器学习"精确匹配
-python -snake排除词
ORcat OR dog或者

## Time Filters
ParameterDescription
tbs=qdr:hPast hour
tbs=qdr:dPast day
tbs=qdr:wPast week
tbs=qdr:mPast month
tbs=qdr:yPast year

## Privacy Engines
- DuckDuckGo: No tracking
- Startpage: Google results + privacy
- Brave: Independent index
- Qwant: EU GDPR compliant

## Bangs Shortcuts (DuckDuckGo)
BangDestination
!gGoogle
!ghGitHub
!soStack Overflow
!wWikipedia
!ytYouTube

## WolframAlpha Queries
- Math: integrate x^2 dx
- Conversion: 100 USD to CNY
- Stocks: AAPL stock
- Weather: weather in Beijing

## Documentation
- references/advanced-search.md - Domestic search guide
- references/international-search.md - International search guide
- CHANGELOG.md - Version history

## License
MIT